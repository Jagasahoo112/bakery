USE [Bakery]
GO
/****** Object:  Table [dbo].[Dailysell]    Script Date: 16-04-2023 14:03:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dailysell](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ItemName] [nvarchar](50) NULL,
	[ItemQty] [nvarchar](50) NULL,
	[Price] [nvarchar](50) NULL,
	[Date] [nvarchar](50) NULL,
	[Value1] [nvarchar](50) NULL,
	[Value2] [nvarchar](50) NULL,
	[Value3] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LoginTable]    Script Date: 16-04-2023 14:03:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoginTable](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](50) NULL,
	[Password] [nvarchar](50) NULL,
	[UserType] [nvarchar](50) NULL,
	[Company] [nvarchar](50) NULL
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Dailysell] ON 
GO
INSERT [dbo].[Dailysell] ([Id], [ItemName], [ItemQty], [Price], [Date], [Value1], [Value2], [Value3]) VALUES (1, N'qwdqwd', N'111', N'11212', N'string', N'asdasdasdasdas', NULL, NULL)
GO
INSERT [dbo].[Dailysell] ([Id], [ItemName], [ItemQty], [Price], [Date], [Value1], [Value2], [Value3]) VALUES (2, N'', N'', N'435', N'2023-04-16', N'', NULL, NULL)
GO
INSERT [dbo].[Dailysell] ([Id], [ItemName], [ItemQty], [Price], [Date], [Value1], [Value2], [Value3]) VALUES (3, N'', N'', N'435sw', N'2023-04-16', N'', NULL, NULL)
GO
INSERT [dbo].[Dailysell] ([Id], [ItemName], [ItemQty], [Price], [Date], [Value1], [Value2], [Value3]) VALUES (4, N'', N'', N'435sw', N'2023-04-16', N'', NULL, NULL)
GO
INSERT [dbo].[Dailysell] ([Id], [ItemName], [ItemQty], [Price], [Date], [Value1], [Value2], [Value3]) VALUES (5, N'Cake1', N'123', N'w123123', N'2023-04-16', N'', NULL, NULL)
GO
INSERT [dbo].[Dailysell] ([Id], [ItemName], [ItemQty], [Price], [Date], [Value1], [Value2], [Value3]) VALUES (6, N'asda', N'1233', N'4444', N'2023-04-18', N'qewwqweqw', NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[Dailysell] OFF
GO
SET IDENTITY_INSERT [dbo].[LoginTable] ON 
GO
INSERT [dbo].[LoginTable] ([Id], [UserId], [Password], [UserType], [Company]) VALUES (1, N'123', N'987654321', N'A', N'JB')
GO
SET IDENTITY_INSERT [dbo].[LoginTable] OFF
GO
/****** Object:  StoredProcedure [dbo].[spinsertdailysells]    Script Date: 16-04-2023 14:03:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 

CREATE PROCEDURE  [dbo].[spinsertdailysells](
    @ItemName AS VARCHAR(500)= '', 
    @ItemQty AS VARCHAR(500)= '', 
    @Price AS VARCHAR(500)= ''  ,
	  @Date AS VARCHAR(500)= ''  , 
	  @Value1 AS VARCHAR(500)= ''  
    
  ) AS
  
  BEGIN 
  
   SET NOCOUNT ON;
	INSERT INTO [dbo].[Dailysell]
           ([ItemName]
           ,[ItemQty]
           ,[Price]
           ,[Date]
           ,[Value1]
           )
     VALUES
           (@ItemName,@ItemQty,@Price,@Date,@Value1)
	 
	 select 'Success'

END
GO
/****** Object:  StoredProcedure [dbo].[spLoginDetailsDev]    Script Date: 16-04-2023 14:03:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 

CREATE PROCEDURE  [dbo].[spLoginDetailsDev](
    @UserName AS VARCHAR(500)= '', 
    @Password AS VARCHAR(500)= '', 
    @UserTypey AS VARCHAR(500)= ''  
    
  ) AS
  
  BEGIN 
  
   SET NOCOUNT ON;
	IF EXISTS 
   
	(SELECT  UserId,[Password],UserType
		FROM dbo.[LoginTable]
		WHERE UserId=@UserName AND [Password]=@Password)
		begin 
		select 'Success'
		end
	else 
		select 'Fail'
	 

END
GO
/****** Object:  StoredProcedure [dbo].[spSellDetailsDev]    Script Date: 16-04-2023 14:03:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 

CREATE PROCEDURE  [dbo].[spSellDetailsDev] 
   
    AS
  
  BEGIN 
  
   SET NOCOUNT ON;
	 select 
            * from 
		    [dbo].[Dailysell]
            
	 

END
GO
